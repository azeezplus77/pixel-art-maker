// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()

function makeGrid() {
// Your code goes here!
  event.preventDefault();
	const h = document.getElementById('inputHeight').value;
	const w = document.getElementById('inputWidth').value;
	const table = document.getElementById("pixelCanvas");
  const colorPicker = document.getElementById("colorPicker");
  const cells = document.getElementsByClassName('cell');
  var grid = [];

	for (var i = 0; i < h; i++) {
			grid += "<tr class='row-" + i + "'>";
  	for (var j = 0; j < w; j++) {
				grid += '<td class="cell" id="row-' + i + '_cell-' + j + '"></td>';
			}
			grid += '</tr>';
	}
	table.innerHTML = grid;
	for (var i = 0; i < cells.length; i++) {
		cells[i].addEventListener("click", function () {
				var x = event.target;
				x.style.backgroundColor = colorPicker.value;
			});
	}
}
document.getElementById('sizePicker').onsubmit = function () {
    makeGrid();
};
